import { useState } from "react";
import Header from "./components/Header";
import ListingsPage from "./components/ListingsPage";
import AddProductForm from "./components/AddProductForm";

type View = "listings" | "add";

export default function App() {
  const [view, setView] = useState<View>("listings");
  const [listingCount, setListingCount] = useState(0);
  const [successMsg, setSuccessMsg] = useState(false);

  const handlePostSuccess = () => {
    setSuccessMsg(true);
    setView("listings");
    setTimeout(() => setSuccessMsg(false), 3000);
  };

  return (
    <div style={{ minHeight: "100vh" }}>
      <Header view={view} onNavigate={setView} listingCount={listingCount} />

      {/* Toast */}
      {successMsg && (
        <div style={{
          position: "fixed", top: 80, left: "50%",
          transform: "translateX(-50%)",
          background: "var(--accent)",
          color: "#080b12",
          fontWeight: 700,
          padding: "12px 24px",
          borderRadius: 12,
          zIndex: 1000,
          boxShadow: "0 8px 32px rgba(0,232,122,0.3)",
          animation: "fadeUp 0.3s ease forwards",
          fontSize: "0.95rem",
        }}>
          ✅ Listing posted successfully!
        </div>
      )}

      {view === "listings" && <ListingsPage />}
      {view === "add" && <AddProductForm onSuccess={handlePostSuccess} />}
    </div>
  );
}
