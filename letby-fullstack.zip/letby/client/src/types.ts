export type Category =
  | "Electronics"
  | "Clothing"
  | "Vehicles"
  | "Furniture"
  | "Food"
  | "Services"
  | "Other";

export type Listing = {
  id: string;
  title: string;
  price: string;
  description: string;
  seller_username: string;
  category: Category;
  image_url?: string;
  location?: string;
  created_at: string;
};

export const CATEGORIES: Category[] = [
  "Electronics", "Clothing", "Vehicles",
  "Furniture", "Food", "Services", "Other"
];

export const CATEGORY_ICONS: Record<Category, string> = {
  Electronics: "📱",
  Clothing:    "👗",
  Vehicles:    "🚗",
  Furniture:   "🛋️",
  Food:        "🍽️",
  Services:    "🔧",
  Other:       "📦"
};

export const formatPrice = (price: string) => {
  const num = parseFloat(price.replace(/[^0-9.]/g, ""));
  if (isNaN(num)) return price;
  return new Intl.NumberFormat("en-ET").format(num) + " ETB";
};
