import React from "react";

type View = "listings" | "add";

type Props = {
  view: View;
  onNavigate: (v: View) => void;
  listingCount: number;
};

export default function Header({ view, onNavigate, listingCount }: Props) {
  return (
    <header style={{
      position: "sticky",
      top: 0,
      zIndex: 100,
      background: "rgba(8,11,18,0.85)",
      backdropFilter: "blur(20px)",
      borderBottom: "1px solid var(--border)",
      padding: "0 24px",
    }}>
      <div style={{
        maxWidth: 1200,
        margin: "0 auto",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        height: 64,
      }}>
        {/* Logo */}
        <div
          onClick={() => onNavigate("listings")}
          style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 10 }}
        >
          <div style={{
            width: 36, height: 36,
            background: "var(--accent)",
            borderRadius: 10,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontFamily: "var(--font-head)",
            fontWeight: 800,
            fontSize: "1.1rem",
            color: "#080b12",
          }}>L</div>
          <span style={{
            fontFamily: "var(--font-head)",
            fontWeight: 800,
            fontSize: "1.4rem",
            letterSpacing: "-0.03em",
          }}>
            Let<span style={{ color: "var(--accent)" }}>By</span>
          </span>
          <span style={{
            background: "var(--surface2)",
            border: "1px solid var(--border)",
            borderRadius: 20,
            padding: "2px 10px",
            fontSize: "0.75rem",
            color: "var(--muted)",
            fontWeight: 500,
          }}>{listingCount} listings</span>
        </div>

        {/* Nav */}
        <nav style={{ display: "flex", gap: 8 }}>
          <NavBtn active={view === "listings"} onClick={() => onNavigate("listings")}>
            Browse
          </NavBtn>
          <NavBtn active={view === "add"} onClick={() => onNavigate("add")} accent>
            + Sell
          </NavBtn>
        </nav>
      </div>
    </header>
  );
}

function NavBtn({
  children, active, onClick, accent
}: {
  children: React.ReactNode;
  active: boolean;
  onClick: () => void;
  accent?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "8px 18px",
        borderRadius: 10,
        fontFamily: "var(--font-body)",
        fontWeight: 600,
        fontSize: "0.9rem",
        transition: "all 0.2s",
        background: accent
          ? active ? "var(--accent)" : "rgba(0,232,122,0.12)"
          : active ? "var(--surface2)" : "transparent",
        color: accent
          ? active ? "#080b12" : "var(--accent)"
          : active ? "var(--text)" : "var(--muted)",
        border: accent ? "1px solid var(--accent)" : "1px solid transparent",
      }}
    >
      {children}
    </button>
  );
}
