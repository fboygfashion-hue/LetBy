import { useState, useEffect, useCallback } from "react";
import { Listing, Category, CATEGORIES, CATEGORY_ICONS } from "../types";
import ListingCard from "./ListingCard";

const API = "/listings";

export default function ListingsPage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<"All" | Category>("All");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(t);
  }, [search]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (debouncedSearch) params.set("search", debouncedSearch);
      if (category !== "All") params.set("category", category);

      const res = await fetch(`${API}?${params}`);
      const data = await res.json();
      setListings(data);
    } catch {
      setListings([]);
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, category]);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    if (!confirm("Remove this listing?")) return;
    await fetch(`${API}/${id}`, { method: "DELETE" });
    setListings(prev => prev.filter(l => l.id !== id));
  };

  return (
    <div style={{ maxWidth: 1200, margin: "0 auto", padding: "32px 20px 60px" }}>

      {/* Search bar */}
      <div style={{ marginBottom: 24, position: "relative" }}>
        <span style={{
          position: "absolute", left: 16, top: "50%",
          transform: "translateY(-50%)",
          fontSize: "1.1rem", pointerEvents: "none",
        }}>🔍</span>
        <input
          placeholder="Search listings…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{
            paddingLeft: 46,
            fontSize: "1rem",
            height: 48,
            borderRadius: 12,
          }}
        />
      </div>

      {/* Category filter */}
      <div style={{
        display: "flex", gap: 8, flexWrap: "wrap",
        marginBottom: 32,
      }}>
        <FilterChip
          label="All"
          active={category === "All"}
          onClick={() => setCategory("All")}
        />
        {CATEGORIES.map(cat => (
          <FilterChip
            key={cat}
            label={`${CATEGORY_ICONS[cat]} ${cat}`}
            active={category === cat}
            onClick={() => setCategory(cat)}
          />
        ))}
      </div>

      {/* Results info */}
      <div style={{
        color: "var(--muted)", fontSize: "0.85rem",
        marginBottom: 20, fontWeight: 500,
      }}>
        {loading ? "Loading…" : `${listings.length} listing${listings.length !== 1 ? "s" : ""} found`}
      </div>

      {/* Grid */}
      {loading ? (
        <SkeletonGrid />
      ) : listings.length === 0 ? (
        <EmptyState />
      ) : (
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: 20,
        }}>
          {listings.map((item, i) => (
            <ListingCard key={item.id} listing={item} onDelete={handleDelete} index={i} />
          ))}
        </div>
      )}
    </div>
  );
}

function FilterChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "7px 16px",
        borderRadius: 20,
        fontSize: "0.85rem",
        fontWeight: 600,
        transition: "all 0.15s",
        background: active ? "var(--accent)" : "var(--surface)",
        color: active ? "#080b12" : "var(--muted)",
        border: active ? "1px solid var(--accent)" : "1px solid var(--border)",
      }}
    >{label}</button>
  );
}

function SkeletonGrid() {
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
      gap: 20,
    }}>
      {[...Array(6)].map((_, i) => (
        <div key={i} style={{
          background: "var(--surface)",
          border: "1px solid var(--border)",
          borderRadius: "var(--radius)",
          height: 320,
          animation: "pulse 1.5s ease infinite",
          animationDelay: `${i * 0.1}s`,
        }} />
      ))}
    </div>
  );
}

function EmptyState() {
  return (
    <div style={{
      textAlign: "center", padding: "80px 20px",
      color: "var(--muted)",
    }}>
      <div style={{ fontSize: "3rem", marginBottom: 16 }}>📭</div>
      <h3 style={{ fontFamily: "var(--font-head)", fontWeight: 700, fontSize: "1.3rem", marginBottom: 8, color: "var(--text)" }}>
        No listings found
      </h3>
      <p>Try a different search or category.</p>
    </div>
  );
}
