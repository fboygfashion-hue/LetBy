import { useState } from "react";
import { Category, CATEGORIES, CATEGORY_ICONS } from "../types";

type FormData = {
  title: string;
  price: string;
  description: string;
  seller_username: string;
  category: Category;
  image_url: string;
  location: string;
};

type Props = {
  onSuccess: () => void;
};

const API = "/listings";

export default function AddProductForm({ onSuccess }: Props) {
  const [form, setForm] = useState<FormData>({
    title: "",
    price: "",
    description: "",
    seller_username: "",
    category: "Electronics",
    image_url: "",
    location: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const set = (field: keyof FormData) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => setForm(prev => ({ ...prev, [field]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!form.title.trim() || !form.price.trim() || !form.seller_username.trim()) {
      setError("Please fill in all required fields.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      if (!res.ok) throw new Error("Failed to post listing");
      onSuccess();
    } catch {
      setError("Failed to post listing. Is the server running?");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      maxWidth: 640,
      margin: "40px auto",
      padding: "0 20px 60px",
      animation: "fadeUp 0.4s ease forwards",
    }}>
      <div style={{ marginBottom: 32 }}>
        <h2 style={{
          fontFamily: "var(--font-head)",
          fontWeight: 800,
          fontSize: "2rem",
          letterSpacing: "-0.03em",
        }}>Post a Listing</h2>
        <p style={{ color: "var(--muted)", marginTop: 6 }}>
          Fill in the details below to sell your item.
        </p>
      </div>

      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>

        {/* Category */}
        <div>
          <Label>Category *</Label>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 8 }}>
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                type="button"
                onClick={() => setForm(prev => ({ ...prev, category: cat }))}
                style={{
                  padding: "7px 14px",
                  borderRadius: 10,
                  fontSize: "0.85rem",
                  fontWeight: 600,
                  transition: "all 0.15s",
                  background: form.category === cat ? "var(--accent)" : "var(--surface2)",
                  color: form.category === cat ? "#080b12" : "var(--muted)",
                  border: form.category === cat ? "1px solid var(--accent)" : "1px solid var(--border)",
                }}
              >
                {CATEGORY_ICONS[cat]} {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Title */}
        <Field label="Title *">
          <input
            placeholder="e.g. iPhone 13 Pro Max"
            value={form.title}
            onChange={set("title")}
            required
          />
        </Field>

        {/* Price */}
        <Field label="Price (ETB) *">
          <input
            type="number"
            placeholder="e.g. 25000"
            value={form.price}
            onChange={set("price")}
            required
          />
        </Field>

        {/* Description */}
        <Field label="Description">
          <textarea
            rows={4}
            placeholder="Describe your item — condition, features, etc."
            value={form.description}
            onChange={set("description")}
            style={{ resize: "vertical" }}
          />
        </Field>

        {/* Seller Username */}
        <Field label="Telegram Username *">
          <input
            placeholder="@yourname"
            value={form.seller_username}
            onChange={set("seller_username")}
            required
          />
        </Field>

        {/* Image URL */}
        <Field label="Image URL (optional)">
          <input
            placeholder="https://..."
            value={form.image_url}
            onChange={set("image_url")}
          />
        </Field>

        {/* Location */}
        <Field label="Location (optional)">
          <input
            placeholder="e.g. Addis Ababa"
            value={form.location}
            onChange={set("location")}
          />
        </Field>

        {error && (
          <div style={{
            background: "rgba(255,71,87,0.1)",
            border: "1px solid rgba(255,71,87,0.3)",
            borderRadius: 10, padding: "12px 16px",
            color: "var(--danger)", fontSize: "0.9rem",
          }}>{error}</div>
        )}

        <button
          type="submit"
          disabled={loading}
          style={{
            marginTop: 8,
            padding: "15px",
            background: loading ? "var(--surface2)" : "var(--accent)",
            color: loading ? "var(--muted)" : "#080b12",
            fontFamily: "var(--font-head)",
            fontWeight: 700,
            fontSize: "1rem",
            borderRadius: 12,
            transition: "all 0.2s",
            cursor: loading ? "not-allowed" : "pointer",
          }}
        >
          {loading ? "Posting…" : "Post Listing"}
        </button>
      </form>
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <label style={{
      display: "block",
      fontWeight: 600,
      fontSize: "0.85rem",
      color: "var(--muted)",
      marginBottom: 6,
      textTransform: "uppercase",
      letterSpacing: "0.06em",
    }}>{children}</label>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <Label>{label}</Label>
      {children}
    </div>
  );
}
