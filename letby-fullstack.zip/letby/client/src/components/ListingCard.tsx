import { Listing, CATEGORY_ICONS, formatPrice } from "../types";

type Props = {
  listing: Listing;
  onDelete: (id: string) => void;
  index: number;
};

export default function ListingCard({ listing, onDelete, index }: Props) {
  const icon = CATEGORY_ICONS[listing.category] || "📦";
  const timeAgo = getTimeAgo(listing.created_at);

  return (
    <div
      className="fade-up"
      style={{
        animationDelay: `${index * 0.06}s`,
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: "var(--radius)",
        overflow: "hidden",
        transition: "transform 0.2s, border-color 0.2s, box-shadow 0.2s",
        cursor: "default",
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLDivElement).style.transform = "translateY(-3px)";
        (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(0,232,122,0.3)";
        (e.currentTarget as HTMLDivElement).style.boxShadow = "0 8px 32px rgba(0,0,0,0.4)";
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLDivElement).style.transform = "translateY(0)";
        (e.currentTarget as HTMLDivElement).style.borderColor = "var(--border)";
        (e.currentTarget as HTMLDivElement).style.boxShadow = "none";
      }}
    >
      {/* Image */}
      <div style={{ position: "relative", height: 180, background: "var(--surface2)" }}>
        {listing.image_url ? (
          <img
            src={listing.image_url}
            alt={listing.title}
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
            onError={e => { (e.target as HTMLImageElement).style.display = "none"; }}
          />
        ) : (
          <div style={{
            height: "100%", display: "flex", alignItems: "center",
            justifyContent: "center", fontSize: "3rem"
          }}>{icon}</div>
        )}
        {/* Category badge */}
        <span style={{
          position: "absolute", top: 10, left: 10,
          background: "rgba(8,11,18,0.85)",
          backdropFilter: "blur(8px)",
          border: "1px solid var(--border)",
          borderRadius: 20, padding: "3px 10px",
          fontSize: "0.75rem", fontWeight: 600, color: "var(--text)",
        }}>
          {icon} {listing.category}
        </span>
      </div>

      {/* Content */}
      <div style={{ padding: "16px" }}>
        <h3 style={{
          fontFamily: "var(--font-head)",
          fontWeight: 700,
          fontSize: "1.05rem",
          marginBottom: 6,
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
        }}>{listing.title}</h3>

        <p style={{
          color: "var(--muted)",
          fontSize: "0.85rem",
          marginBottom: 12,
          display: "-webkit-box",
          WebkitLineClamp: 2,
          WebkitBoxOrient: "vertical",
          overflow: "hidden",
          lineHeight: 1.5,
        }}>{listing.description || "No description provided."}</p>

        {/* Price */}
        <div style={{
          fontSize: "1.2rem",
          fontFamily: "var(--font-head)",
          fontWeight: 800,
          color: "var(--accent)",
          marginBottom: 12,
        }}>{formatPrice(listing.price)}</div>

        {/* Footer */}
        <div style={{
          display: "flex", alignItems: "center",
          justifyContent: "space-between",
          paddingTop: 12,
          borderTop: "1px solid var(--border)",
        }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            <a
              href={`https://t.me/${listing.seller_username.replace("@", "")}`}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                color: "var(--accent)",
                fontWeight: 600,
                fontSize: "0.85rem",
              }}
            >
              {listing.seller_username}
            </a>
            {listing.location && (
              <span style={{ color: "var(--muted)", fontSize: "0.78rem" }}>
                📍 {listing.location}
              </span>
            )}
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ color: "var(--muted)", fontSize: "0.75rem" }}>{timeAgo}</span>
            <a
              href={`https://t.me/${listing.seller_username.replace("@", "")}`}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                background: "var(--accent)",
                color: "#080b12",
                fontWeight: 700,
                fontSize: "0.8rem",
                padding: "6px 14px",
                borderRadius: 8,
                transition: "background 0.2s",
              }}
              onMouseEnter={e => (e.currentTarget.style.background = "var(--accent2)")}
              onMouseLeave={e => (e.currentTarget.style.background = "var(--accent)")}
            >
              Contact
            </a>
            <button
              onClick={() => onDelete(listing.id)}
              title="Remove listing"
              style={{
                background: "rgba(255,71,87,0.12)",
                color: "var(--danger)",
                border: "1px solid rgba(255,71,87,0.2)",
                borderRadius: 8,
                padding: "6px 10px",
                fontSize: "0.85rem",
                transition: "background 0.2s",
              }}
              onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,71,87,0.25)")}
              onMouseLeave={e => (e.currentTarget.style.background = "rgba(255,71,87,0.12)")}
            >🗑</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function getTimeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}
