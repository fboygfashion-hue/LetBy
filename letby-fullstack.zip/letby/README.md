# LetBy — Buy & Sell in Ethiopia 🇪🇹

A full-stack Telegram-compatible marketplace app built with React + TypeScript (frontend) and Express + TypeScript (backend).

## 🚀 Quick Start

### Prerequisites
- Node.js v18+
- npm

### 1. Install All Dependencies

```bash
# From root of project
npm install
npm --prefix server install
npm --prefix client install
```

Or with the helper script:
```bash
npm run install:all
```

### 2. Run in Development

```bash
# From root — starts both server and client together
npm run dev
```

- **Backend** → http://localhost:3000
- **Frontend** → http://localhost:5173

---

## 📁 Project Structure

```
letby-app/
├── package.json          # Root: concurrently scripts
├── tsconfig.json         # Server TS config
├── server/
│   ├── package.json
│   └── index.ts          # Express API
└── client/
    ├── package.json
    ├── vite.config.ts     # Proxies /listings → localhost:3000
    ├── index.html
    └── src/
        ├── main.tsx
        ├── App.tsx
        ├── index.css
        ├── types.ts
        └── components/
            ├── Header.tsx
            ├── ListingsPage.tsx
            ├── ListingCard.tsx
            └── AddProductForm.tsx
```

---

## 🔌 API Endpoints

| Method | Route              | Description                              |
|--------|--------------------|------------------------------------------|
| GET    | /listings          | Get all listings (supports ?search=&category=) |
| GET    | /listings/:id      | Get single listing                       |
| POST   | /listings          | Create a listing                         |
| DELETE | /listings/:id      | Delete a listing                         |
| GET    | /categories        | List all categories                      |
| GET    | /health            | Server health check                      |

### POST /listings body

```json
{
  "title": "iPhone 13",
  "price": "45000",
  "description": "Great condition",
  "seller_username": "@myname",
  "category": "Electronics",
  "image_url": "https://...",
  "location": "Addis Ababa"
}
```

---

## 🌐 Deploy to Render

1. Push to GitHub
2. Create a **Web Service** on [render.com](https://render.com)
3. Set **Root Directory** to `server`
4. Set **Build Command**: `npm install`
5. Set **Start Command**: `npm start`
6. Update `API` in `client/vite.config.ts` to your Render URL

---

## ✨ Features

- Browse, search & filter listings by category
- Post new listings with image, location, price
- Delete listings
- Telegram contact integration
- Responsive dark-mode UI
- Vite proxy setup (no CORS in dev)
