import express, { Request, Response } from "express";
import cors from "cors";
import { v4 as uuidv4 } from "uuid";

const app = express();
app.use(cors());
app.use(express.json());

export type Category =
  | "Electronics"
  | "Clothing"
  | "Vehicles"
  | "Furniture"
  | "Food"
  | "Services"
  | "Other";

export type Listing = {
  id: string;
  title: string;
  price: string;
  description: string;
  seller_username: string;
  category: Category;
  image_url?: string;
  location?: string;
  created_at: string;
};

let listings: Listing[] = [
  {
    id: uuidv4(),
    title: "iPhone 13 Pro Max",
    price: "58000",
    description: "Excellent condition, battery health 92%, comes with original box and charger.",
    seller_username: "@jacstore",
    category: "Electronics",
    image_url: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=400",
    location: "Addis Ababa",
    created_at: new Date().toISOString()
  },
  {
    id: uuidv4(),
    title: "Toyota Corolla 2019",
    price: "1800000",
    description: "Single owner, low mileage, clean interior. Automatic transmission.",
    seller_username: "@autoethiopia",
    category: "Vehicles",
    image_url: "https://images.unsplash.com/photo-1590362891991-f776e747a588?w=400",
    location: "Addis Ababa",
    created_at: new Date().toISOString()
  },
  {
    id: uuidv4(),
    title: "Samsung 55\" Smart TV",
    price: "22000",
    description: "4K UHD, 1 year old, barely used. Includes remote and original stand.",
    seller_username: "@teklu_tech",
    category: "Electronics",
    image_url: "https://images.unsplash.com/photo-1593784991095-a205069470b6?w=400",
    location: "Hawassa",
    created_at: new Date().toISOString()
  },
  {
    id: uuidv4(),
    title: "Traditional Habesha Kemis",
    price: "3500",
    description: "Handwoven, size M, worn once for a ceremony. Beautiful embroidery.",
    seller_username: "@meron_fashion",
    category: "Clothing",
    image_url: "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=400",
    location: "Gondar",
    created_at: new Date().toISOString()
  }
];

// ─── GET all listings (with optional search & category filter) ───────────────
app.get("/listings", (req: Request, res: Response) => {
  const { search, category } = req.query;

  let results = [...listings];

  if (category && category !== "All") {
    results = results.filter(l => l.category === category);
  }

  if (search) {
    const q = (search as string).toLowerCase();
    results = results.filter(
      l =>
        l.title.toLowerCase().includes(q) ||
        l.description.toLowerCase().includes(q) ||
        l.location?.toLowerCase().includes(q)
    );
  }

  res.json(results.reverse());
});

// ─── GET single listing ──────────────────────────────────────────────────────
app.get("/listings/:id", (req: Request, res: Response) => {
  const listing = listings.find(l => l.id === req.params.id);
  if (!listing) return res.status(404).json({ error: "Listing not found" });
  res.json(listing);
});

// ─── POST create listing ─────────────────────────────────────────────────────
app.post("/listings", (req: Request, res: Response) => {
  const { title, price, description, seller_username, category, image_url, location } = req.body;

  if (!title || !price || !seller_username || !category) {
    return res.status(400).json({ error: "title, price, seller_username and category are required" });
  }

  const newListing: Listing = {
    id: uuidv4(),
    title,
    price,
    description: description || "",
    seller_username,
    category,
    image_url: image_url || "",
    location: location || "",
    created_at: new Date().toISOString()
  };

  listings.push(newListing);
  res.status(201).json(newListing);
});

// ─── DELETE listing ──────────────────────────────────────────────────────────
app.delete("/listings/:id", (req: Request, res: Response) => {
  const index = listings.findIndex(l => l.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: "Listing not found" });
  listings.splice(index, 1);
  res.json({ ok: true });
});

// ─── GET categories ───────────────────────────────────────────────────────────
app.get("/categories", (_req: Request, res: Response) => {
  const cats: Category[] = ["Electronics", "Clothing", "Vehicles", "Furniture", "Food", "Services", "Other"];
  res.json(cats);
});

// ─── Health check ─────────────────────────────────────────────────────────────
app.get("/health", (_req, res) => res.json({ status: "ok", listings: listings.length }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n  🟢 LetBy server running on http://localhost:${PORT}\n`);
});
