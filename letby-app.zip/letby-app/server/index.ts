import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

type Listing = {
  title: string;
  price: string;
  description: string;
  seller_username: string;
};

let listings: Listing[] = [
  {
    title: "iPhone 11",
    price: "25000 ETB",
    description: "Clean condition",
    seller_username: "@jacstore"
  }
];

app.get("/listings", (req, res) => {
  res.json(listings);
});

app.post("/listings", (req, res) => {
  listings.push(req.body);
  res.json({ ok: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Server running on " + PORT));
