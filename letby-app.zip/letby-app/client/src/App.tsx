import { useEffect, useState } from "react";

type Listing = {
  title: string;
  price: string;
  description: string;
  seller_username: string;
};

const API = "https://letby.onrender.com";

export default function App() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [form, setForm] = useState<Listing>({
    title: "",
    price: "",
    description: "",
    seller_username: ""
  });
  const [success, setSuccess] = useState(false);

  const loadListings = async () => {
    const res = await fetch(API + "/listings");
    const data = await res.json();
    setListings(data);
  };

  useEffect(() => {
    loadListings();
  }, []);

  const handleSubmit = async (e: any) => {
    e.preventDefault();

    await fetch(API + "/listings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });

    setSuccess(true);
    loadListings();
  };

  return (
    <div style={{ padding: 20, fontFamily: "Arial", background: "#0f172a", color: "white", minHeight: "100vh" }}>
      <h1>LetBy</h1>

      {!success && (
        <form onSubmit={handleSubmit}>
          <input placeholder="Title" onChange={e => setForm({ ...form, title: e.target.value })} />
          <input placeholder="Price" onChange={e => setForm({ ...form, price: e.target.value })} />
          <textarea placeholder="Description" onChange={e => setForm({ ...form, description: e.target.value })} />
          <input placeholder="@username" onChange={e => setForm({ ...form, seller_username: e.target.value })} />
          <button type="submit">Post Product</button>
        </form>
      )}

      {success && <h2>✅ Product Posted</h2>}

      <div>
        {listings.map((item, i) => (
          <div key={i} style={{ background: "#1e293b", marginTop: 10, padding: 10 }}>
            <h3>{item.title}</h3>
            <p>{item.price}</p>
            <p>{item.description}</p>
            <a
              href={`https://t.me/${item.seller_username.replace("@", "")}`}
              target="_blank"
            >
              Contact Seller
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}
