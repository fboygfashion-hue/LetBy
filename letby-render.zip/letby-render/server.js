const express = require("express");
const cors = require("cors");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(cors());
app.use(express.json());

// ─── In-memory store ─────────────────────────────────────────────────────────
let listings = [
  {
    id: uuidv4(),
    title: "iPhone 13 Pro Max",
    price: "58000",
    description: "Excellent condition, battery health 92%, comes with original box and charger.",
    seller_username: "@jacstore",
    category: "Electronics",
    image_url: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=400",
    location: "Addis Ababa",
    created_at: new Date().toISOString()
  },
  {
    id: uuidv4(),
    title: "Toyota Corolla 2019",
    price: "1800000",
    description: "Single owner, low mileage, clean interior. Automatic transmission.",
    seller_username: "@autoethiopia",
    category: "Vehicles",
    image_url: "https://images.unsplash.com/photo-1590362891991-f776e747a588?w=400",
    location: "Addis Ababa",
    created_at: new Date().toISOString()
  },
  {
    id: uuidv4(),
    title: "Samsung 55\" Smart TV",
    price: "22000",
    description: "4K UHD, 1 year old, barely used. Includes remote and original stand.",
    seller_username: "@teklu_tech",
    category: "Electronics",
    image_url: "https://images.unsplash.com/photo-1593784991095-a205069470b6?w=400",
    location: "Hawassa",
    created_at: new Date().toISOString()
  }
];

// ─── GET listings (with search + category filter) ────────────────────────────
app.get("/listings", (req, res) => {
  const { search, category } = req.query;
  let results = [...listings];

  if (category && category !== "All") {
    results = results.filter(l => l.category === category);
  }

  if (search) {
    const q = search.toLowerCase();
    results = results.filter(l =>
      l.title.toLowerCase().includes(q) ||
      l.description.toLowerCase().includes(q) ||
      (l.location && l.location.toLowerCase().includes(q))
    );
  }

  res.json(results.reverse());
});

// ─── GET single listing ───────────────────────────────────────────────────────
app.get("/listings/:id", (req, res) => {
  const listing = listings.find(l => l.id === req.params.id);
  if (!listing) return res.status(404).json({ error: "Not found" });
  res.json(listing);
});

// ─── POST create listing ──────────────────────────────────────────────────────
app.post("/listings", (req, res) => {
  const { title, price, description, seller_username, category, image_url, location } = req.body;

  if (!title || !price || !seller_username || !category) {
    return res.status(400).json({ error: "title, price, seller_username and category are required" });
  }

  const newListing = {
    id: uuidv4(),
    title,
    price,
    description: description || "",
    seller_username,
    category,
    image_url: image_url || "",
    location: location || "",
    created_at: new Date().toISOString()
  };

  listings.push(newListing);
  res.status(201).json(newListing);
});

// ─── DELETE listing ───────────────────────────────────────────────────────────
app.delete("/listings/:id", (req, res) => {
  const index = listings.findIndex(l => l.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: "Not found" });
  listings.splice(index, 1);
  res.json({ ok: true });
});

// ─── GET categories ───────────────────────────────────────────────────────────
app.get("/categories", (req, res) => {
  res.json(["Electronics", "Clothing", "Vehicles", "Furniture", "Food", "Services", "Other"]);
});

// ─── Health check ─────────────────────────────────────────────────────────────
app.get("/health", (req, res) => {
  res.json({ status: "ok", listings: listings.length });
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n  🟢 LetBy server running on port ${PORT}\n`);
});
