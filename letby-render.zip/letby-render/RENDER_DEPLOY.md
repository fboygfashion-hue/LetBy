# LetBy Server — Render Deploy Guide

## ✅ Render Settings

| Setting        | Value          |
|----------------|----------------|
| **Runtime**    | Node            |
| **Root Dir**   | *(leave blank)* |
| **Build Cmd**  | `npm install`   |
| **Start Cmd**  | `node server.js`|

## Why it was failing

Render runs `npm install` then `node server.js`. The old project had
`express` inside `server/package.json` — but Render was running at the
root level where express wasn't installed.

This fixed version puts **everything at the root**:
- `package.json` with express, cors, uuid
- `server.js` plain JavaScript (no TypeScript build step needed)

## API Endpoints

| Method | Route         | Description                         |
|--------|---------------|-------------------------------------|
| GET    | /listings     | All listings (?search=&category=)   |
| GET    | /listings/:id | Single listing                      |
| POST   | /listings     | Create listing                      |
| DELETE | /listings/:id | Delete listing                      |
| GET    | /categories   | List all categories                 |
| GET    | /health       | Health check                        |
